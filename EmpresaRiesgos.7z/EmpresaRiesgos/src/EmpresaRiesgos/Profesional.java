package EmpresaRiesgos;

/**
 *  Principio Abierto/Cerrado: La clase Profesional puede ser extendida para agregar funcionalidades 
 * adicionales sin modificar su código fuente original. Esto se observa en el hecho de que 
 * Profesional es una subclase de Usuario, lo que permite extender su funcionalidad mediante herencia.
 * 
 * La clase Profesional representa un tipo de usuario que es un profesional dentro de la empresa de riesgos.
 * Hereda de la clase Usuario e implementa funcionalidades específicas para profesionales.
 */
public class Profesional extends Usuario {

    private String titulo;      // Título del profesional
    private String fechaIngreso; // Fecha de ingreso del profesional

    /**
     * Constructor que inicializa un objeto Profesional con los parámetros dados.
     * @param nombre Nombre del profesional.
     * @param fechaNacimiento Fecha de nacimiento del profesional en formato "YYYY-MM-DD".
     * @param run RUN del profesional.
     * @param titulo Título del profesional.
     * @param fechaIngreso Fecha de ingreso del profesional en formato "YYYY-MM-DD".
     */
    public Profesional(String nombre, String fechaNacimiento, int run, String titulo, String fechaIngreso) {
        super(nombre, fechaNacimiento, run);
        this.titulo = titulo;
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * Constructor sin parámetros de la clase Profesional.
     */
    public Profesional() {
    }

    /**
     * Obtiene el título del profesional.
     * @return Título del profesional.
     */
    public String gettitulo() {
        return titulo;
    }

    /**
     * Establece el título del profesional.
     * @param titulo Título a establecer para el profesional.
     */
    public void settitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene la fecha de ingreso del profesional.
     * @return Fecha de ingreso del profesional en formato "YYYY-MM-DD".
     */
    public String getfechaIngreso() {
        return fechaIngreso;
    }

    /**
     * Establece la fecha de ingreso del profesional.
     * @param fechaIngreso Fecha de ingreso a establecer para el profesional en formato "YYYY-MM-DD".
     */
    public void setfechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    /**
     * Método que muestra la información detallada del usuario, incluyendo el título y la fecha de ingreso del profesional.
     */
    @Override
    public void analizarUsuario() {
        super.analizarUsuario(); // Llama al método de la superclase para mostrar la información básica del usuario
        System.out.println("Título: " + titulo);
        System.out.println("Fecha de ingreso: " + fechaIngreso);
    }
}
