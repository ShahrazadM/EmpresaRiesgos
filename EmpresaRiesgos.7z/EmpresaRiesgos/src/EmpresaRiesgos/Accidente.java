package EmpresaRiesgos;

/** Accidente pertenese a clase principio de Responsabilidad única al tener una sola razón para cambiar, 
 * que es la representación y manipulación de los datos del accidente.
 * La clase Accidente representa un evento de accidente registrado por el cliente.
 */
public class Accidente {

    private int identificadorAc;
    private int rutCliente;
    private String dia;
    private String hora;
    private String lugar;
    private String origen;
    private String consecuencias;

    /**
     * Constructor con parámetros para inicializar un objeto Accidente.
     *
     * @param identificadorAc Identificador único del accidente.
     * @param rutCliente      Rut del cliente asociado al accidente.
     * @param dia             Día en que ocurrió el accidente (formato DD/MM/AAAA).
     * @param hora            Hora en que ocurrió el accidente (formato HH:MM).
     * @param lugar           Lugar donde ocurrió el accidente.
     * @param origen          Origen del accidente.
     * @param consecuencias   Consecuencias del accidente.
     */
    public Accidente(int identificadorAc, int rutCliente, String dia, String hora, String lugar, String origen,
                     String consecuencias) {
        this.identificadorAc = identificadorAc;
        this.rutCliente = rutCliente;
        this.dia = dia;
        this.hora = hora;
        this.lugar = lugar;
        this.origen = origen;
        this.consecuencias = consecuencias;
    }

    /**
     * Constructor sin parámetros de Accidente.
     */
    public Accidente() {
    }

    /**
     * Método de acceso para obtener el identificador del accidente.
     *
     * @return El identificador del accidente.
     */
    public int getidentificadorAc() {
        return identificadorAc;
    }

    /**
     * Método de modificación para establecer el identificador del accidente.
     *
     * @param identificadorAc El nuevo identificador del accidente.
     */
    public void setidentificadorAC(int identificadorAc) {
        this.identificadorAc = identificadorAc;
    }

    /**
     * Método de acceso para obtener el rut del cliente asociado al accidente.
     *
     * @return El rut del cliente asociado al accidente.
     */
    public int getrutCliente() {
        return rutCliente;
    }

    /**
     * Método de modificación para establecer el rut del cliente asociado al accidente.
     *
     * @param rutCliente El nuevo rut del cliente asociado al accidente.
     */
    public void setrutCliente(int rutCliente) {
        this.rutCliente = rutCliente;
    }

    /**
     * Método de acceso para obtener el día en que ocurrió el accidente.
     *
     * @return El día en que ocurrió el accidente.
     */
    public String getdia() {
        return dia;
    }

    /**
     * Método de modificación para establecer el día en que ocurrió el accidente.
     *
     * @param dia El nuevo día en que ocurrió el accidente (formato DD/MM/AAAA).
     */
    public void setdia(String dia) {
        this.dia = dia;
    }

    /**
     * Método de acceso para obtener la hora en que ocurrió el accidente.
     *
     * @return La hora en que ocurrió el accidente.
     */
    public String hora() {
        return hora;
    }

    /**
     * Método de modificación para establecer la hora en que ocurrió el accidente.
     *
     * @param hora La nueva hora en que ocurrió el accidente (formato HH:MM).
     */
    public void sethora(String hora) {
        this.hora = hora;
    }

    /**
     * Método de acceso para obtener el lugar donde ocurrió el accidente.
     *
     * @return El lugar donde ocurrió el accidente.
     */
    public String lugar() {
        return lugar;
    }

    /**
     * Método de modificación para establecer el lugar donde ocurrió el accidente.
     *
     * @param lugar El nuevo lugar donde ocurrió el accidente.
     */
    public void setlugar(String lugar) {
        this.lugar = lugar;
    }

    /**
     * Método de acceso para obtener el origen del accidente.
     *
     * @return El origen del accidente.
     */
    public String origen() {
        return origen;
    }

    /**
     * Método de modificación para establecer el origen del accidente.
     *
     * @param origen El nuevo origen del accidente.
     */
    public void setorigen(String origen) {
        this.origen = origen;
    }

    /**
     * Método de acceso para obtener las consecuencias del accidente.
     *
     * @return Las consecuencias del accidente.
     */
    public String consecuencias() {
        return consecuencias;
    }

    /**
     * Método de modificación para establecer las consecuencias del accidente.
     *
     * @param consecuencias Las nuevas consecuencias del accidente.
     */
    public void setconsecuencias(String consecuencias) {
        this.consecuencias = consecuencias;
    }

    /**
     * Método toString para representar un objeto Accidente como una cadena de texto.
     *
     * @return Una cadena que representa el objeto Accidente.
     */
    @Override
    public String toString() {
        return "Accidente{" +
                "Identificador=" + identificadorAc +
                ", RutCliente=" + rutCliente +
                ", Dia='" + dia + '\'' +
                ", Hora='" + hora + '\'' +
                ", Lugar='" + lugar + '\'' +
                ", Origen='" + origen + '\'' +
                ", Consecuencias='" + consecuencias + '\'' +
                '}';
    }
}