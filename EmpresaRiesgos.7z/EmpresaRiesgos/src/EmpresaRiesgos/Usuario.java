package EmpresaRiesgos;

import java.time.LocalDate;
import java.time.Period;

/**
 *  Principio de sustitución de Liskov: La clase Usuario es una clase base para Cliente y Profesional, 
 * y se utiliza polimorfismo para tratar a las instancias de estas clases de manera uniforme. 
 * Esto cumple con el principio de sustitución de Liskov, ya que las instancias de las subclases 
 * pueden ser utilizadas en lugar de instancias de la clase base sin alterar el comportamiento esperado.
 * 
 * La clase abstracta Usuario representa un usuario genérico del sistema.
 * Implementa la interfaz Asesoria e incluye atributos comunes como nombre, fecha de nacimiento y RUN.
 */
public abstract class Usuario implements Asesoria {

    // Atributos

    private String nombre;           // Nombre del usuario
    private String fechaNacimiento;  // Fecha de nacimiento del usuario (formato YYYY-MM-DD)
    private int run;                 // RUN (Rol Único Nacional) del usuario

    /**
     * Constructor que inicializa un objeto Usuario con los parámetros dados.
     * @param nombre Nombre del usuario.
     * @param fechaNacimiento Fecha de nacimiento del usuario (formato YYYY-MM-DD).
     * @param run RUN (Rol Único Nacional) del usuario.
     */
    public Usuario(String nombre, String fechaNacimiento, int run) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.run = run;
    }

    /**
     * Constructor sin parámetros de la clase Usuario.
     */
    public Usuario() {
    }

    /**
     * Obtiene el nombre del usuario.
     * @return Nombre del usuario.
     */
    public String getnombre() {
        return nombre;
    }

    /**
     * Establece el nombre del usuario.
     * @param nombre Nombre a establecer para el usuario.
     */
    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la fecha de nacimiento del usuario.
     * @return Fecha de nacimiento del usuario (formato YYYY-MM-DD).
     */
    public String getfechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Establece la fecha de nacimiento del usuario.
     * @param fechaNacimiento Fecha de nacimiento a establecer para el usuario (formato YYYY-MM-DD).
     */
    public void setfechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    /**
     * Obtiene el RUN (Rol Único Nacional) del usuario.
     * @return RUN del usuario.
     */
    public int getrun() {
        return run;
    }

    /**
     * Establece el RUN (Rol Único Nacional) del usuario.
     * @param run RUN a establecer para el usuario.
     */
    public void setrun(int run) {
        this.run = run;
    }

    /**
     * Método para mostrar la edad del usuario a partir de su fecha de nacimiento.
     * Calcula la edad actual del usuario y muestra un mensaje con la edad.
     */
    public void mostrarEdad() {
        // Obtener la fecha actual
        LocalDate ahora = LocalDate.now();

        // Parsear la fecha de nacimiento a LocalDate
        LocalDate fechaNac = LocalDate.parse(fechaNacimiento);

        // Calcular la diferencia de años entre la fecha actual y la fecha de nacimiento
        Period periodo = Period.between(fechaNac, ahora);
        int edad = periodo.getYears();

        // Mostrar un mensaje con la edad del usuario
        System.out.println("El usuario tiene " + edad + " años.");
    }

    /**
     * Método para analizar y mostrar los datos básicos del usuario.
     * Muestra el nombre y el RUN del usuario.
     */
    public void analizarUsuario() {
        System.out.println("Nombre: " + nombre);
        System.out.println("RUN: " + run);
    }

    /**
     * Método complementario para mostrar todos los datos del usuario.
     * Llama a los métodos analizarUsuario() y mostrarEdad() para mostrar los datos completos del usuario.
     */
    public void mostrarDatosUsuario() {
        System.out.println("Datos del Usuario:");
        analizarUsuario(); // Llama al método analizarUsuario() para mostrar nombre y RUN
        mostrarEdad();     // Llama al método mostrarEdad() para mostrar la edad del usuario
    }

    /**
     * Método toString para representar el objeto Usuario como cadena.
     * @return Representación en cadena del objeto Usuario.
     */
    @Override
    public String toString() {
        return "Usuario{" +
                "nombre='" + nombre + '\'' +
                ", fechaNacimiento='" + fechaNacimiento + '\'' +
                ", run=" + run +
                '}';
    }

    /**
     * Obtiene el RUN (Rol Único Nacional) del usuario.
     * @return RUN del usuario.
     */
    public int getRun() {
        return run;
    }

}