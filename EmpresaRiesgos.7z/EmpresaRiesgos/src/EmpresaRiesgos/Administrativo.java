package EmpresaRiesgos;

/**
 * Principio Abierto/Cerrado: La clase Administrativo puede ser extendida para a
 * gregar funcionalidades adicionales sin modificar su código fuente original. 
 * Esto se observa en el hecho de que Administrativo es una subclase de Usuario 
 * y también implementa la interfaz Asesoria, lo que permite extender su funcionalidad 
 * mediante herencia y composición
 * La clase Administrativo representa a un usuario que desempeña funciones administrativas en la empresa.
 * Extiende de la clase Usuario e implementa la interfaz Asesoria.
 */
public class Administrativo extends Usuario implements Asesoria {

    // Atributos

    private String area; // Área de trabajo del administrativo
    private String experienciaPrevia; // Experiencia previa del administrativo

    /**
     * Constructor para crear un objeto Administrativo con parámetros.
     *
     * @param nombre           Nombre del administrativo.
     * @param fechaNacimiento  Fecha de nacimiento del administrativo (formato DD/MM/AAAA).
     * @param run              RUN del administrativo.
     * @param area             Área de trabajo del administrativo.
     * @param experienciaPrevia Experiencia previa del administrativo.
     */
    public Administrativo(String nombre, String fechaNacimiento, int run, String area, String experienciaPrevia) {
        super(nombre, fechaNacimiento, run); // Llama al constructor de la clase base (Usuario)
        this.area = area;
        this.experienciaPrevia = experienciaPrevia;
    }

    /**
     * Constructor sin parámetros de la clase Administrativo.
     */
    public Administrativo() {
        // Constructor vacío
    }

    /**
     * Método de acceso para obtener el área de trabajo del administrativo.
     *
     * @return El área de trabajo del administrativo.
     */
    public String getarea() {
        return area;
    }

    /**
     * Método de modificación para establecer el área de trabajo del administrativo.
     *
     * @param area El nuevo área de trabajo del administrativo.
     */
    public void setarea(String area) {
        this.area = area;
    }

    /**
     * Método de acceso para obtener la experiencia previa del administrativo.
     *
     * @return La experiencia previa del administrativo.
     */
    public String experienciaPrevia() {
        return experienciaPrevia;
    }

    /**
     * Método de modificación para establecer la experiencia previa del administrativo.
     *
     * @param experienciaPrevia La nueva experiencia previa del administrativo.
     */
    public void setexperienciaPrevia(String experienciaPrevia) {
        this.experienciaPrevia = experienciaPrevia;
    }

    /**
     * Método que analiza al administrativo mostrando sus datos.
     * Incluye los datos heredados de Usuario (nombre, RUN) y los atributos específicos de Administrativo (área, experiencia previa).
     */
    @Override
    public void analizarUsuario() {
        super.analizarUsuario(); // Llama al método analizarUsuario de la clase base (Usuario)
        System.out.println("Área: " + area);
        System.out.println("Experiencia previa: " + experienciaPrevia);
    }
}