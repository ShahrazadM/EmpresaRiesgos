package EmpresaRiesgos;
/**
 * Proyecto Empresa Riesgos
 * Este proyecto permite desde un menú generar 9 opciones
 *  que permitirán gestionar, administrar y mantener una administración de los distintos usuarios que utilizarán el proyecto además de permitir mantener un registro de las capacitaciones que la empresa necesita.
 * @version 1.0
 *
 * @author Ruben Riquelme:
*Nayareth Sepulveda:
*Frasiel Camp:
*Scherezade Huancapaza
*
 */
import java.util.Scanner;

/**
 * La clase Principal representa la interfaz de usuario principal para interactuar con el sistema.
 * Permite realizar operaciones como almacenar usuarios y capacitaciones, eliminar usuarios,
 * listar usuarios y capacitaciones, y salir del programa.
 */
public class Principal {

    /**
     * Método principal que inicia la aplicación.
     * @param args Argumentos de línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Contenedor contenedor = new Contenedor(); // Creamos una instancia de la clase Contenedor

        int opcion;
        do {
            System.out.println("\nMenú Principal:");
            System.out.println("1. Almacenar Cliente");
            System.out.println("2. Almacenar Profesional");
            System.out.println("3. Almacenar Administrativo");
            System.out.println("4. Almacenar Capacitación");
            System.out.println("5. Eliminar Usuario");
            System.out.println("6. Listar Usuarios");
            System.out.println("7. Listar Usuarios por Tipo");
            System.out.println("8. Listar Capacitaciones");
            System.out.println("9. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Almacenar Cliente
                    Cliente cliente = new Cliente();
                    System.out.println("Ingrese el nombre del cliente:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    cliente.setnombre(scanner.nextLine());
                    // Solicitar y establecer los demás datos del cliente
                    System.out.println("Ingrese la fecha de nacimiento del cliente (formato YYYY-MM-DD):");
                    cliente.setfechaNacimiento(scanner.nextLine());
                    System.out.println("Ingrese el RUN del cliente: (formato sin guion)");
                    cliente.setrun(scanner.nextInt());
                    System.out.println("Ingrese el rut del cliente: (formato sin guion)");
                    cliente.setRut(scanner.nextInt());
                    // Solicitar y establecer los demás datos del cliente
                    System.out.println("Ingrese los nombres del cliente:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    cliente.setNombres(scanner.nextLine());
                    System.out.println("Ingrese los apellidos del cliente:");
                    cliente.setApellidos(scanner.nextLine());
                    System.out.println("Ingrese el teléfono del cliente: (Ingrese máximo 10 números)");
                    cliente.setTelefono(scanner.nextInt());
                    System.out.println("Ingrese la AFP del cliente:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    cliente.setAfp(scanner.nextLine());
                    System.out.println("Ingrese el sistema de salud del cliente (1 para Fonasa, 2 para Isapre):");
                    cliente.setSistemaSalud(scanner.nextInt());
                    System.out.println("Ingrese la dirección del cliente:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    cliente.setDireccion(scanner.nextLine());
                    System.out.println("Ingrese la comuna del cliente:");
                    cliente.setComuna(scanner.nextLine());
                    System.out.println("Ingrese la edad del cliente:");
                    cliente.setEdad(scanner.nextInt());
                    contenedor.almacenarCliente(cliente);
                    System.out.println("El cliente:");
                    cliente.mostrarCliente();
                    cliente.analizarUsuario();
                    System.out.println("ha sido agregado correctamente...");
                    break;
                case 2:
                    // Almacenar Profesional
                    Profesional profesional = new Profesional();
                    System.out.println("Ingrese el nombre del profesional:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    profesional.setnombre(scanner.nextLine());
                    // Solicitar y establecer los demás datos del profesional
                    System.out.println("Ingrese la fecha de nacimiento del profesional (formato YYYY-MM-DD):");
                    profesional.setfechaNacimiento(scanner.nextLine());
                    System.out.println("Ingrese el RUN del profesional:");
                    profesional.setrun(scanner.nextInt());
                    System.out.println("Ingrese el título del profesional:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    profesional.settitulo(scanner.nextLine());
                    System.out.println("Ingrese la fecha de ingreso del profesional (formato YYYY-MM-DD):");
                    profesional.setfechaIngreso(scanner.nextLine());
                    contenedor.almacenarProfesional(profesional);
                    System.out.println("El Profesional:");
                    profesional.analizarUsuario();
                    profesional.mostrarEdad();
                    System.out.println("ha sido agregado correctamente...");
                    break;
                case 3:
                    // Almacenar Administrativo
                    Administrativo administrativo = new Administrativo();
                    System.out.println("Ingrese el nombre del administrativo:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    administrativo.setnombre(scanner.nextLine());
                    // Solicitar y establecer los demás datos del administrativo
                    System.out.println("Ingrese la fecha de nacimiento del administrativo (formato YYYY-MM-DD):");
                    administrativo.setfechaNacimiento(scanner.nextLine());
                    System.out.println("Ingrese el RUN del administrativo:");
                    administrativo.setrun(scanner.nextInt());
                    System.out.println("Ingrese el área del administrativo:");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    administrativo.setarea(scanner.nextLine());
                    System.out.println("Ingrese la experiencia previa del administrativo:");
                    administrativo.setexperienciaPrevia(scanner.nextLine());
                    contenedor.almacenarAdministrativo(administrativo);
                    System.out.println("El Administrativo:");
                    administrativo.analizarUsuario();
                    System.out.println("ha sido agregado correctamente...");
                    break;
                case 4:
                    // Almacenar Capacitación
                    Capacitacion capacitacion = new Capacitacion();
                    // Solicitar y establecer los datos de la capacitación
                    System.out.println("Ingrese el identificador de la capacitación:");
                    capacitacion.setIdentificador(scanner.nextInt());
                    System.out.println("Ingrese el RUN del cliente asociado a la capacitación:");
                    capacitacion.setRutCliente(scanner.nextInt());
                    System.out.println("Ingrese el día de la capacitación (formato YYYY-MM-DD):");
                    scanner.nextLine(); // Limpiamos el buffer de entrada
                    capacitacion.setDia(scanner.nextLine());
                    System.out.println("Ingrese la hora de la capacitación (formato HH:mm):");
                    capacitacion.setHora(scanner.nextLine());
                    System.out.println("Ingrese el lugar de la capacitación:");
                    capacitacion.setLugar(scanner.nextLine());
                    System.out.println("Ingrese la duración de la capacitación:");
                    capacitacion.setDuracion(scanner.nextLine());
                    System.out.println("Ingrese la cantidad de asistentes a la capacitación:");
                    capacitacion.setCantidadAsistentes(scanner.nextInt());
                    contenedor.almacenarCapacitacion(capacitacion);
                    System.out.println("La Capacitación:");
                    capacitacion.mostrarDetalle();
                    System.out.println("ha sido agregada correctamente...");
                    break;
                case 5:
                    // Eliminar Usuario
                    System.out.println("Ingrese el RUN del usuario que desea eliminar:");
                    int runEliminar = scanner.nextInt();
                    contenedor.eliminarUsuario(runEliminar);
                    break;
                case 6:

				// Listar Usuarios
				contenedor.listarUsuarios();
				scanner.nextLine(); // Consumir la nueva línea pendiente
				break;
				
			case 7://Listar Usuarios por tipo
				 System.out.print("Ingrese el tipo de usuario (Cliente, Profesional, Administrativo): ");
				    String tipo = scanner.next();
				    contenedor.listarUsuariosPorTipo(tipo);
				    
           break;
			case 8:
				contenedor.listarCapacitaciones();
                break;

			case 9:
				System.out.println("¡Hasta luego!");
				break;
			default:
				System.out.println("Opción no válida. Por favor, ingrese una opción válida.");

			}
		} while (opcion != 9);

		scanner.close();
	}

}




