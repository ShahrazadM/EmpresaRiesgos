package EmpresaRiesgos;

/**
 * Principio de responsabilidad única: La clase Cliente se encarga 
 * únicamente de representar un cliente y proporcionar métodos para acceder y modificar sus atributos. 
 * Cumple con el principio de responsabilidad única al tener una sola razón para cambiar, 
 * que es la representación y manipulación de los datos del cliente.

 * La clase Cliente representa a un cliente de la compañía de asesorías en prevención de riesgos laborales.
 * Contiene información personal del cliente, como nombres, apellidos, teléfono, AFP, sistema de salud, dirección, comuna y edad.
 */
public class Cliente extends Usuario {

    // Atributos

    private int rut;
    private String nombres;
    private String apellidos;
    private int telefono;
    private String afp;
    private int sistemaSalud;
    private String direccion;
    private String comuna;
    private int edad;

    /**
     * Constructor para crear una nueva instancia de Cliente con parámetros específicos.
     *
     * @param nombre          Nombre del cliente.
     * @param fechaNacimiento Fecha de nacimiento del cliente (formato DD/MM/AAAA).
     * @param run             RUN del cliente.
     * @param rut             Rut del cliente.
     * @param nombres         Nombres del cliente.
     * @param apellidos       Apellidos del cliente.
     * @param telefono        Teléfono del cliente.
     * @param afp             AFP a la que está afiliado el cliente.
     * @param sistemaSalud    Tipo de sistema de salud del cliente (1 para Fonasa, 2 para Isapre).
     * @param direccion       Dirección del cliente.
     * @param comuna          Comuna del cliente.
     * @param edad            Edad del cliente.
     */
    public Cliente(String nombre, String fechaNacimiento, int run, int rut, String nombres, String apellidos,
                   int telefono, String afp, int sistemaSalud, String direccion, String comuna, int edad) {
        super(nombre, fechaNacimiento, run);
        this.rut = rut;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.afp = afp;
        this.sistemaSalud = sistemaSalud;
        this.direccion = direccion;
        this.comuna = comuna;
        this.edad = edad;
    }

    /**
     * Constructor sin parámetros para crear una instancia vacía de Cliente.
     */
    public Cliente() {
    }

    // Métodos accesores (getters y setters) para los atributos

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getAfp() {
        return afp;
    }

    public void setAfp(String afp) {
        this.afp = afp;
    }

    public int getSistemaSalud() {
        return sistemaSalud;
    }

    public void setSistemaSalud(int sistemaSalud) {
        this.sistemaSalud = sistemaSalud;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Método para obtener el nombre completo del cliente (nombres + apellidos).
     *
     * @return Nombre completo del cliente.
     */
    public String obtenerNombre() {
        return nombres + " " + apellidos;
    }

    /**
     * Método para obtener el tipo de sistema de salud del cliente (Fonasa o Isapre).
     *
     * @return Tipo de sistema de salud del cliente.
     */
    public String obtenerSistemaSalud() {
        return (sistemaSalud == 1) ? "Fonasa" : "Isapre";
    }

    /**
     * Método para mostrar los datos significativos del cliente.
     */
    public void mostrarCliente() {
        System.out.println("Nombre: " + obtenerNombre());
        System.out.println("RUT: " + rut);
        System.out.println("AFP: " + afp);
        System.out.println("Sistema de Salud: " + obtenerSistemaSalud());
    }

    /**
     * Método para analizar y mostrar los datos del cliente.
     * Este método imprime datos del cliente, incluyendo la dirección y la comuna.
     */
    @Override
    public void analizarUsuario() {
        super.analizarUsuario(); // Llama al método de la clase padre (Usuario)
        System.out.println("Dirección: " + direccion);
        System.out.println("Comuna: " + comuna);
    }
}