package EmpresaRiesgos;

/**
 * * Principio de responsabilidad única: La clase Revision se encarga únicamente de representar una revisión
 *  y proporcionar métodos para acceder y modificar sus atributos. 
 *  Cumple con el principio de responsabilidad única al tener una sola razón para cambiar, que es 
 *  la representación y manipulación de los datos de la revisión.
 *  
 * La clase Revision representa una revisión realizada durante una visita en terreno.
 * Contiene información sobre el identificador de la revisión, el identificador de la visita en terreno,
 * el nombre de la revisión, el detalle de la revisión y el estado de la misma.
 */
public class Revision {

    private int identificadorRevision; // Identificador único de la revisión
    private int identificadorVt;       // Identificador de la visita en terreno asociada a la revisión
    private String nombrerevision;     // Nombre de la revisión
    private String detalle;            // Detalle de la revisión
    private int Estado;                // Estado de la revisión: 1 (sin problemas), 2 (con observaciones), 3 (no aprueba)

    /**
     * Constructor que inicializa un objeto Revision con los parámetros dados.
     * @param identificadorRevision Identificador único de la revisión.
     * @param identificadorVt Identificador de la visita en terreno asociada a la revisión.
     * @param nombrerevision Nombre de la revisión.
     * @param detalle Detalle de la revisión.
     * @param Estado Estado de la revisión (1, 2 o 3).
     */
    public Revision(int identificadorRevision, int identificadorVt, String nombrerevision, String detalle, int Estado) {
        this.identificadorRevision = identificadorRevision;
        this.identificadorVt = identificadorVt;
        this.nombrerevision = nombrerevision;
        this.detalle = detalle;
        this.Estado = validarEstado(Estado); // Validar y establecer el estado al momento de la creación
    }

    /**
     * Constructor sin parámetros de la clase Revision.
     */
    public Revision() {
    }

    /**
     * Obtiene el identificador de la revisión.
     * @return Identificador de la revisión.
     */
    public int getidentificadorRevision() {
        return identificadorRevision;
    }

    /**
     * Establece el identificador de la revisión.
     * @param identificadorRevision Identificador a establecer para la revisión.
     */
    public void setidentificadorRevision(int identificadorRevision) {
        this.identificadorRevision = identificadorRevision;
    }

    /**
     * Obtiene el identificador de la visita en terreno asociada a la revisión.
     * @return Identificador de la visita en terreno.
     */
    public int getidentificadorVt() {
        return identificadorVt;
    }

    /**
     * Establece el identificador de la visita en terreno asociada a la revisión.
     * @param identificadorVt Identificador de la visita en terreno a establecer.
     */
    public void setidentificadorVt(int identificadorVt) {
        this.identificadorVt = identificadorVt;
    }

    /**
     * Obtiene el nombre de la revisión.
     * @return Nombre de la revisión.
     */
    public String getnombrerevision() {
        return nombrerevision;
    }

    /**
     * Establece el nombre de la revisión.
     * @param nombrerevision Nombre a establecer para la revisión.
     */
    public void setnombrerevision(String nombrerevision) {
        this.nombrerevision = nombrerevision;
    }

    /**
     * Obtiene el detalle de la revisión.
     * @return Detalle de la revisión.
     */
    public String getdetalle() {
        return detalle;
    }

    /**
     * Establece el detalle de la revisión.
     * @param detalle Detalle a establecer para la revisión.
     */
    public void setdetalle(String detalle) {
        this.detalle = detalle;
    }

    /**
     * Obtiene el estado de la revisión.
     * @return Estado de la revisión.
     */
    public int getEstado() {
        return Estado;
    }

    /**
     * Establece el estado de la revisión.
     * @param Estado Estado a establecer para la revisión (1, 2 o 3).
     */
    public void setEstado(int Estado) {
        this.Estado = validarEstado(Estado);
    }

    /**
     * Método para validar y establecer el estado de la revisión.
     * @param estado Estado a validar y establecer.
     * @return Estado validado (si es válido) o 1 (sin problemas) por defecto.
     */
    public int validarEstado(int estado) {
        if (estado == 1 || estado == 2 || estado == 3) {
            return estado; // Estado válido
        } else {
            System.out.println("Error: Estado no válido. Se establecerá como 1 (sin problemas) por defecto.");
            return 1; // Si el estado ingresado no es válido, establecer como 1 por defecto
        }
    }

    /**
     * Método toString para representar la revisión como cadena.
     * @return Representación en cadena de la revisión.
     */
    @Override
    public String toString() {
        return "Revision{" +
                "Identificador de Revision=" + identificadorRevision +
                ", Identificador Visita Terreno=" + identificadorVt +
                ", Nombre revision='" + nombrerevision + '\'' +
                ", detalle='" + detalle + '\'' +
                ", Estado='" + Estado + '\'' +
                '}';
    }
}
