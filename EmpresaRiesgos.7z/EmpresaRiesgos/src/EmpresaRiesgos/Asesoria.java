package EmpresaRiesgos;

/**
 * la interfaz Asesoria parece ser coherente con los principios SOLID, específicamente con el SRP y el ISP.
 * Principio de segregación de interfaces: La clase Capacitacion no implementa ninguna interfaz, 
 * por lo que no podemos aplicar directamente el principio de segregación de interfaces en esta clase.
 * 
 * La interfaz Asesoria define un contrato para analizar usuarios en el contexto de la asesoría.
 * Representa la capacidad de un objeto para realizar un análisis específico del usuario.
 */
public interface Asesoria {

    /**
     * Método que permite analizar un usuario en el contexto de la asesoría.
     * Este método debe ser implementado por las clases que implementen esta interfaz.
     */
    void analizarUsuario();

}