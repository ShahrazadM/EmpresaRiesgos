package EmpresaRiesgos;

/**
 *  Principio Abierto/Cerrado: La clase Visitaterreno parece ser una clase de datos simple que se 
 * utiliza para representar una visita en terreno. Cumple con el principio de abierto/cerrado al 
 * no tener métodos que permitan modificar sus atributos directamente, lo que facilita la extensión 
 * de la funcionalidad sin modificar su implementación.
 * 
 * La clase Visitaterreno representa una visita en terreno registrada en el sistema.
 * Contiene atributos que describen la visita, como identificador, rut del cliente, día, hora,
 * lugar y comentarios.
 */
public class Visitaterreno {

    private int identificadorVt;  // Identificador único de la visita en terreno
    private int rutCliente;       // RUN (Rol Único Nacional) del cliente asociado a la visita
    private String dia;           // Día de la visita (formato YYYY-MM-DD)
    private String hora;          // Hora de la visita (formato HH:mm)
    private String lugar;         // Lugar de la visita en terreno
    private String comentarios;   // Comentarios adicionales sobre la visita

    /**
     * Constructor para inicializar una visita en terreno con los parámetros dados.
     * @param identificadorVt Identificador único de la visita en terreno.
     * @param rutCliente RUN (Rol Único Nacional) del cliente asociado a la visita.
     * @param dia Día de la visita (formato YYYY-MM-DD).
     * @param hora Hora de la visita (formato HH:mm).
     * @param lugar Lugar de la visita en terreno.
     * @param comentarios Comentarios adicionales sobre la visita.
     */
    public Visitaterreno(int identificadorVt, int rutCliente, String dia, String hora, String lugar, String comentarios) {
        this.identificadorVt = identificadorVt;
        this.rutCliente = rutCliente;
        this.dia = dia;
        this.hora = hora;
        this.lugar = lugar;
        this.comentarios = comentarios;
    }

    /**
     * Constructor sin parámetros de la clase Visitaterreno.
     */
    public Visitaterreno() {
    }

    // Métodos accesores para identificadorVt

    public int getidentificadorVt() {
        return identificadorVt;
    }

    public void setidentificadorVt(int identificadorVt) {
        this.identificadorVt = identificadorVt;
    }

    // Métodos accesores para rutCliente

    public int getrutCliente() {
        return rutCliente;
    }

    public void setrutCliente(int rutCliente) {
        this.rutCliente = rutCliente;
    }

    // Métodos accesores para dia

    public String getdia() {
        return dia;
    }

    public void setdia(String dia) {
        this.dia = dia;
    }

    // Métodos accesores para hora

    public String gethora() {
        return hora;
    }

    public void sethora(String hora) {
        this.hora = hora;
    }

    // Métodos accesores para lugar

    public String getlugar() {
        return lugar;
    }

    public void setlugar(String lugar) {
        this.lugar = lugar;
    }

    // Métodos accesores para comentarios

    public String getcomentarios() {
        return comentarios;
    }

    public void setcomentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    /**
     * Método toString para representar la visita en terreno como una cadena.
     * @return Representación en cadena de la visita en terreno.
     */
    @Override
    public String toString() {
        return "Visitaterreno{" +
                "Identificador=" + identificadorVt +
                ", RutCliente=" + rutCliente +
                ", Dia='" + dia + '\'' +
                ", Hora='" + hora + '\'' +
                ", Lugar='" + lugar + '\'' +
                ", Comentarios='" + comentarios + '\'' +
                '}';
    }
}
