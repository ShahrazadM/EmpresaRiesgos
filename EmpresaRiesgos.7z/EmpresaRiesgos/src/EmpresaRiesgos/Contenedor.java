package EmpresaRiesgos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/**
 *  Principio de responsabilidad única: La clase Contenedor parece tener varias responsabilidades, 
 * como almacenar usuarios y capacitaciones, listar usuarios y capacitaciones, etc. 
 * Esto podría considerarse una violación del principio de responsabilidad única. 
 * Podría ser refactorizado dividiendo estas responsabilidades en clases separadas para mejorar 
 * la cohesión y reducir la complejidad.

 * La clase Contenedor gestiona listas de usuarios y capacitaciones.
 * Permite almacenar, eliminar y listar usuarios, así como almacenar y listar capacitaciones.
 */
public class Contenedor {

    private List<Asesoria> listaUsuarios;
    private List<Capacitacion> listaCapacitaciones;

    /**
     * Constructor de la clase Contenedor.
     * Inicializa las listas de usuarios y capacitaciones.
     */
    public Contenedor() {
        listaUsuarios = new ArrayList<>();
        listaCapacitaciones = new ArrayList<>();
    }

    /**
     * Almacena un objeto Cliente en la lista de usuarios.
     * @param cliente Objeto Cliente a almacenar.
     */
    public void almacenarCliente(Cliente cliente) {
        listaUsuarios.add(cliente);
    }

    /**
     * Almacena un objeto Profesional en la lista de usuarios.
     * @param profesional Objeto Profesional a almacenar.
     */
    public void almacenarProfesional(Profesional profesional) {
        listaUsuarios.add(profesional);
    }

    /**
     * Almacena un objeto Administrativo en la lista de usuarios.
     * @param administrativo Objeto Administrativo a almacenar.
     */
    public void almacenarAdministrativo(Administrativo administrativo) {
        listaUsuarios.add(administrativo);
    }

    /**
     * Almacena un objeto Capacitacion en la lista de capacitaciones.
     * @param capacitacion Objeto Capacitacion a almacenar.
     */
    public void almacenarCapacitacion(Capacitacion capacitacion) {
        listaCapacitaciones.add(capacitacion);
    }

    /**
     * Elimina un usuario de la lista de usuarios según su RUN.
     * @param runUsuario RUN del usuario a eliminar.
     */
    public void eliminarUsuario(int runUsuario) {
        Iterator<Asesoria> iterator = listaUsuarios.iterator();
        while (iterator.hasNext()) {
            Asesoria usuario = iterator.next();
            if (usuario instanceof Usuario && ((Usuario) usuario).getRun() == runUsuario) {
                iterator.remove();
                System.out.println("Usuario eliminado exitosamente.");
                return;
            }
        }
        System.out.println("Usuario con RUN " + runUsuario + " no encontrado.");
    }

    /**
     * Lista todos los usuarios almacenados en el contenedor.
     */
    public void listarUsuarios() {
        for (Asesoria asesoria : listaUsuarios) {
            System.out.println(asesoria);
        }
    }

    /**
     * Lista usuarios por tipo (cliente, profesional, administrativo).
     * @param tipo Tipo de usuario a listar.
     */
    public void listarUsuariosPorTipo(String tipo) {
        for (Asesoria asesoria : listaUsuarios) {
            if (asesoria.getClass().getSimpleName().equalsIgnoreCase(tipo)) {
                System.out.println(asesoria);
            }
        }
    }

    /**
     * Lista todas las capacitaciones almacenadas en el contenedor.
     */
    public void listarCapacitaciones() {
        for (Capacitacion capacitacion : listaCapacitaciones) {
            System.out.println(capacitacion);
        }
    }

    /**
     * Permite ingresar un nuevo usuario (cliente, profesional o administrativo) al contenedor.
     * @param scanner Scanner para leer la entrada del usuario.
     */
    public void ingresarNuevoUsuario(Scanner scanner) {
        System.out.println("Ingrese el tipo de usuario (cliente, profesional, administrativo): ");
        String tipoUsuario = scanner.next();
        scanner.nextLine(); // Limpiar el buffer de entrada

        switch (tipoUsuario.toLowerCase()) {
            case "cliente":
                Cliente cliente = new Cliente();
                // Lógica para solicitar y establecer datos del cliente
                almacenarCliente(cliente);
                System.out.println("Cliente almacenado exitosamente.");
                break;
            case "profesional":
                Profesional profesional = new Profesional();
                // Lógica para solicitar y establecer datos del profesional
                almacenarProfesional(profesional);
                System.out.println("Profesional almacenado exitosamente.");
                break;
            case "administrativo":
                Administrativo administrativo = new Administrativo();
                // Lógica para solicitar y establecer datos del administrativo
                almacenarAdministrativo(administrativo);
                System.out.println("Administrativo almacenado exitosamente.");
                break;
            default:
                System.out.println("Tipo de usuario no válido.");
        }
    }
}
	




